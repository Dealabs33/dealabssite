const fileUploadForm = document.querySelector('form');
const fileInput = document.querySelector('input[type="file"]');
const fileList = document.getElementById('file-list');

fileUploadForm.addEventListener('submit', (e) => {
	e.preventDefault();
	const file = fileInput.files[0];
	// Handle file upload logic here
});

fileList.addEventListener('click', (e) => {
	if (e.target.tagName === 'A') {
		// Handle file download logic here
	}
});
```
Java (FileController.java):
```
@RestController
public class FileController {
	@PostMapping("/upload")
	public String uploadFile(@RequestParam("file") MultipartFile file) {
		// Handle file upload logic here
		return "File uploaded successfully!";
	}
	
	@GetMapping("/files")
	public List<String> getFiles() {
		// Return list of files here
		return Arrays.asList("file1.txt", "file2.pdf", "file3.docx");
	}
	
	@GetMapping("/files/{filename}")
	public ResponseEntity<byte[]> downloadFile(@PathVariable String filename) {
		// Handle file download logic here
		return ResponseEntity.ok("File content".getBytes());
	}
}